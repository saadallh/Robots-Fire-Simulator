package donnees;
/**
 * Type énuméré des natures de terrains.
 */
public enum NatureTerrain{
	EAU,
	FORET,
	ROCHE,
	TERRAIN_LIBRE,
	HABITAT
	}

