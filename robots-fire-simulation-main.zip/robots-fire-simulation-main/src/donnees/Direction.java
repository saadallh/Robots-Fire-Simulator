package donnees;
/**
 * Type énumeré des directions de bases : nord, sud, est et ouest
 */
public enum Direction{
		NORD,
		SUD,
		EST,
		OUEST
}